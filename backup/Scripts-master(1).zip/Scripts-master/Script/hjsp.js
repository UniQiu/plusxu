/*
花椒视频解锁VIP
http://user.shywck.com/user/userinfo
*/


body = $response.body.replace(/.+/, "r2E18C9eded9yAup6iRND3cJpuvlH0xMj3haW7LLQ2Ql3QH3Ugtzp+puIMQNDGNAuYHySilwAzFklM4SIn/AqrOf6MzJCQZ43+PsMSgtnGYceWLgqScXVCwXFQXKR0Cxm7uDE1nEz+hfJnKq9oD6sgNiz7KibxRv1n1mQyXUPkCusDvhverqxX73YhJ5EWJGt5ITAcPg8WeE7FDPFRLvbA==")
$done({body});
